1. Non si può fare perché le props sono di sola lettura e i dati scendono solo dal padre ai figli (flusso unidirezionale). Il dato online vive in App dentro servers, quindi dovrebbe cambiarlo App e ripassarlo giù. Per farlo però ci manca ancora useState per gestire lo stato e far aggiornare la pagina.

2. Non può succedere perché sia SchedaServer che contaPerStato chiamano la stessa funzione statoServer sugli stessi dati che arrivano da App, quindi i colori delle schede e i numeri del riepilogo coincidono per forza.

3. Scelgo BadgeStato. Passandogli solo la stringa stato resta molto più semplice e non deve sapere niente del resto del server, fa solo colore e scritta e così volendo si può riusare anche da altre parti.


