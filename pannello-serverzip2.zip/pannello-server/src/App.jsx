import "./App.css"
import { sistema, servers, avvisi } from "./dati"
import { contaPerStato, cpuMedia, piuLento, trovaServer } from "./calcoli"
import Intestazione from "./Intestazione"
import Riepilogo from "./Riepilogo"
import GrigliaServer from "./GrigliaServer"
import ServerInEvidenza from "./ServerInEvidenza"
import Avvisi from "./Avvisi"

function App() {
  const online = servers.filter(s => s.online).length
  const cercato = "db-01"
  const serverTrovato = trovaServer(servers, cercato)

  return (
    <div className="pannello">
      <Intestazione
        nome={sistema.nome}
        aggiornato={sistema.aggiornato}
        online={online}
        totale={servers.length}
      />

      <Riepilogo
        ok={contaPerStato(servers, "ok")}
        attenzione={contaPerStato(servers, "attenzione")}
        critici={contaPerStato(servers, "critico")}
        offline={contaPerStato(servers, "offline")}
        mediaCpu={cpuMedia(servers)}
        lento={piuLento(servers)}
      />

      <GrigliaServer servers={servers} />

      <ServerInEvidenza cercato={cercato} server={serverTrovato} />

      <Avvisi elenco={avvisi} />
    </div>
  )
}

export default App

/*
Risposte sfida blackout
1. se i server fossero 7 nella griglia se ne vedrebbero comunque solo 6 perché in GrigliaServer li ho scritti da servers[0] a servers[5], se invece fossero 5 la pagina darebbe errore perché servers[5] sarebbe undefined e SchedaServer proverebbe a leggerne le proprietà
2. é il modello dichiarativo: l'interfaccia descrive come mostrare i dati quindi cambiando solo i dati in ingresso React aggiorna da solo tutti i componenti senza doverli modificare a mano
*/